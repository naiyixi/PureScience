# KRAS G12D 突变体靶向抑制剂与胰腺导管腺癌(PDAC)耐药机制——多模态数据调研报告

- **调研执行日期**:2026-09-04
- **数据快照时间**:2026-09-04(所有 Connector 提取均在该时点完成;DepMap 源故障、CADD 许可门控的判定均以该时点为准)
- **数据源**:ChEMBL(EBI)、ClinicalTrials.gov、cBioPortal(CCLE, study `ccle_broad_2019`)、gnomAD v4、ClinVar(经 gnomAD 镜像)、RCSB PDB、PubChem、PubMed(摘要级全文引证)
- **关联产物**:`merged_kras_evidence.csv`(清洗后整合表)、`kras_figure.png`(+矢量 `kras_figure.svg`)、可复现脚本 `01_build_merged_evidence.py`、`02_make_kras_figure.py`、`intermediate/*.json`(不可变中间快照)

---

## 核实词表(证据分级)

本报告严格区分以下三档,不使用"大概/可能"替代核实:

| 标记 | 含义 |
|---|---|
| 【已核实·源】 | 从指定 Connector 或指定同行评审文献(带 PMID/DOI)直接提取,原文/原始记录支持 |
| 【已核实·推导】 | 由已核实值做透明算术/结构推导(给出公式与出处),可复核 |
| 【无法核实/缺口】 | 尝试后源不可用(记录故障原文)、源不收录、或工具无法解析;**绝不推断数值** |

凡标注 GAP 之处,均计入文末《未解析/数据源冲突报告》。

---

## 1. 执行摘要

1. 三个处于临床或临床前高活性的 **KRAS G12D** 抑制剂完成交叉比对:**MRTX1133**(Mirati/BMS)、**RMC-9805 / zoldonrasib**(Revolution Medicines)、**HRS-4642**(恒瑞)。三者覆盖了 G12D 抑制剂的两大化学范式:**非共价高亲和**(MRTX1133、HRS-4642)与 **CypA 依赖的共价(修饰 Asp12)**(RMC-9805)。
2. 关键药理事实(全部可溯源):MRTX1133 对 **GDP 结合态** KRAS G12D 的 KD ≈ **0.2 pM**、结合 IC50 < 2 nM、相对 KRAS WT 结合选择性约 700 倍;细胞水平中位 IC50 ≈ 5 nM,在 KRAS G12D 系中较 KRAS WT 系选择性 >1000 倍;在 11 个 PDAC 模型中 8 个(73%)观察到 ≥30% 肿瘤退缩【已核实·源:PMID 36216931】。
3. 临床试验交叉比对:MRTX1133 唯一 PDAC 相关注册(NCT05737706)已 **TERMINATED**;RMC-9805/zoldonrasib 有 4 项胰腺相关试验(含 **III 期一线 PDAC RCT — NCT07621718 "RASolute 305"**,2026-05 启动);HRS-4642 有 **12 项**胰腺相关注册(含 III 期 NCT07232875 与 II 期+ 多项 PDAC 联合方案),其 ph1b/2 + AG 在晚期 PDAC 一线报告 **确认 ORR 63.3%**(n=30)【已核实·源:各 NCT 记录;PMID 42426224】。
4. KRAS G12D 变异:GRCh38 `12-25245350 C>T`(负链转录本上为 c.35G>A;p.Gly12Asp),gnomAD 种系等位频率极低(exome 2.7×10⁻⁶);ClinVar **Pathogenic/Likely pathogenic(2 星,多提交者无冲突)**。
5. **对抗性测试结论**:所谓"MRTX1133 与 KRAS G12D 的 Asp12 羧基**形成共价键**"的说法在化学原理与结构证据上均不成立——MRTX1133 的规范结构不含任何亲电弹头;其真实结合模式是**非共价、可逆**地占据 Switch-II 口袋(SII-P),对 Asp12 以**盐桥/离子相互作用**实现突变选择性(证据见第 6 章与 PDB 7RPZ/7XKJ)。真正的"共价靶向 G12D-Asp"由另立分子的化学实现(如 RMC-9805 需 CypA 新形态界面催化;β-内酯弹头;嫁接酰基重氮弹头到 MRTX1133 骨架的 KN2-H)。
6. **依赖度数据缺口**:DepMap 官方 API 在本次调研全程返回 `fetch failed`(源端故障,>10 次带间隔重试),因此 **Chronos 基因效应分数无法核实、未取任何数值**。报告以 CCLE(cBioPortal)的细胞系 KRAS 突变型别 + ChEMBL/文献的细胞水平药物反应作为经过核实的替代证据,并把缺口显式登记(见第 7 章与第 10 章)。
7. CADD 评分同样未能获取:连接器被 **non-commercial 许可门控**拦截(记录原始报错),未编造数值;以 ClinVar 意义 + gnomAD 频率 + KRAS 强约束指标作"危害性"的经核实代理。

---

## 2. 方法学与数据流

```
Connector 层(经 REPL 控制面 host.mcp)
 ├ ChEMBL        → MRTX1133 条目与全部可及活性行(activity_id 级)
 ├ ClinicalTrials→ 每化合物 × pancreatic 条件检索 + NCT 级详情
 ├ cBioPortal    → CCLE KRAS 突变(胰腺系, study ccle_broad_2019)
 ├ gnomAD/ClinVar→ KRAS G12D 坐标/等位频率/临床意义;KRAS 约束
 ├ PDB           → 7RPZ / 7XKJ / 9CTB / 7EW9 等条目 + 配体化学
 ├ PubChem       → 三化合物 CID / 分子式 / 规范异构 SMILES
 └ PubMed        → 关键原始论文摘要(带 PMID/DOI)做"数值转录"与条件标注
        │  每次提取落盘为不可变 JSON 快照(intermediate/*.json)
        ▼
Python(kras-env, pandas 3.0.5)整合·清洗·统计校验
 ├ 01_build_merged_evidence.py → merged_kras_evidence.csv(121 行,4 域)
 └ 02_make_kras_figure.py      → kras_figure.png / .svg
```

**统计校验要点**(脚本内含):活动行按 `activity_id` 去重(0 重复行);试验按 NCT 去重(17 个唯一);每一条数值行保留 `verified` 列与 `source_id`(ChEMBL activity_id / NCT / PMID / CCLE 变异记录),缺失值(DepMap Chronos、CADD)以 NaN + `DEPMAP-UNAVAILABLE` / `CADD-BLOCKED` 标记,不填充。

---

## 3. 阶段一:小分子抑制剂交叉比对与活性谱系

### 3.1 三个化合物的化学身份(结构均经真实数据库解析)

| 属性 | MRTX1133 | RMC-9805(zoldonrasib) | HRS-4642 |
|---|---|---|---|
| 研发方 | Mirati(BMS 收购)【已核实·源:CT.gov】 | Revolution Medicines | 江苏恒瑞 |
| ChEMBL ID | **CHEMBL4858364**(另有立体异构记录 CHEMBL5081048) | **不在 ChEMBL**(GAP) | **不在 ChEMBL**(GAP) |
| PubChem CID | 156124857 | 168201327 | 171853615 |
| 分子式 | C33H31F3N6O2 | C63H88F3N11O7 | C34H35F3N6O3 |
| 分子量(计算) | 600.65 | 1168.4 | 632.7 |
| 结合范式 | 非共价、可逆 | **共价**(CypA 介导修饰 D12) | 非共价 |
| 核苷酸状态倾向 | **GDP(非激活)态优先**(SII-P) | **GTP/激活(RAS-ON)态**(三复合物) | 论文未限定(GAP:条件未注明) |

**规范异构 SMILES(【已核实·源:PubChem 2026-09-04】)**

- **MRTX1133**: `C#CC1=C(C=CC2=CC(=CC(=C21)C3=NC=C4C(=C3F)N=C(N=C4N5CC6CCC(C5)N6)OC[C@@]78CCCN7C[C@@H](C8)F)O)F`
  - 与 ChEMBL 分子式一致;结构分析:含 **炔基(芳基乙炔)、苯酚 OH、芳香 C–F、叔胺/二氮杂双环、氟代吡咯里西啶甲醚**,**无任何共价弹头**(无 Michael 受体、无 β-内酯/环氧/氮丙啶、无离去基团、无酰基重氮)——见第 6 章。
- **RMC-9805 (zoldonrasib)**: `C[C@@H](C1=C(C=C(C=N1)N2CCN(CC2)C3CC3)C4=C5CC(COC(=O)[C@@H]6CCCN(N6)C(=O)[C@H](C[C@H]7CN(CCO7)C8=CC5=C(N4CC(F)(F)F)C=C8)NC(=O)[C@H](C9CCCC9)N1CC[C@@]2(C1)CCN(C2)C(=O)[C@H]1[C@H](N1C)C1CC1)(C)C)OC`
  - 结构含 **N-甲基氮丙啶-2-羰基**(图中 `[C@H]1[C@H](N1C)C1CC1` 片段),即共价反应弹头前体。
- **HRS-4642**: `CCC1=C(C=CC2=CC(=CC(=C21)C3=C(C4=C5C(=NC(=N4)OC[C@@]67CCCN6C[C@@H](C7)F)N8C[C@H]9CC[C@@H]([C@H]8COC5=N3)N9)F)O)F`
  - 与 MRTX1133 同属吡啶并嘧啶-萘酚骨架的密切类似物。

### 3.2 MRTX1133 的 ChEMBL 生物活性提取(【已核实·源:ChEMBL, CHEMBL4858364】)

ChEMBL 共返回 MRTX1133 的 ~45 条活性行(B=结合/生化 19、F=功能 22、ADMET 2、毒理 2)。代表性条目(截取,全量见 `merged_kras_evidence.csv`):

| activity_id | 靶点(ChEMBL 标注) | 类型 | 值 | 单位 | pChEMBL | assay | 备注 |
|---|---|---|---|---|---|---|---|
| 23316918 | GTPase KRas | IC50 | 0.4 | nM | 9.40 | CHEMBL4845550 | 生化/结合 |
| 24842027 | Unchecked(CHEMBL612545) | Kd | **<0.0002** | nM | – | CHEMBL5145744 | 结合;见注释 ⓐ |
| 24842036 | GTPase KRas | Kd | **<0.0002** | nM | – | CHEMBL5145749 | SPR 结合 ⓐ |
| 25663212 | **ASPC1**(PDAC, G12D) | IC50 | 11.0 | nM | 7.96 | CHEMBL5374161 | 细胞增殖功能 |
| 25663224 | **HPAC**(PDAC, G12D) | IC50 | 4.2 | nM | 8.38 | CHEMBL5374165 | 细胞增殖功能 |
| 25663225 | **HPAF-II**(PDAC, G12D) | IC50 | 14.9 | nM | 7.83 | CHEMBL5374166 | 细胞增殖功能 |
| 29301821 | ASPC1 | IC50 | 56.8 | nM | 7.25 | CHEMBL6181338 | 另一文档复测 |
| 25663242 | ASPC1 | Activity | 94 % | – | – | CHEMBL5374172 | 另见 TGI 行 |

> ⓐ **关于 0.2 pM 级 KD 的谨慎标注**:ChEMBL 记录关系符为 `<`(即"低于检出上限 0.0002 nM"),与 Nat Med 原文 "KD ≈ 0.2 pM" 表述一致【已核实·源:PMID 36216931 摘要】。0.2 pM 处于 SPR 灵敏度下限附近,应视为**上界量级**,不宜过解读为精确平衡解离常数(见第 10 章冲突/未解析登记)。**测量条件(核苷酸态)**:ChEMBL 行字段本身不编码 GDP/GTP 态;论文层面明确该 KD 为 **GDP-loaded** KRAS G12D 的 SPR 测定【已核实·源:PMID 36216931】。ChEMBL 内 target 标注为 "Unchecked" 的行其 ChEMBL target CHEMBL612545 身份无法经本工具集解析为具体蛋白/细胞系名(GAP,第 10 章)。

### 3.3 活性谱系小结与"测量条件是否区分 GDP/GTP 态"

- **MRTX1133**: **区分并偏好 GDP 态**。KD(GDP-KRAS G12D)≈0.2 pM(上界);论文亦以共晶/生化说明其对 GTP(激活)态的抑制**【已核实·源:PMID 36216931】;JMB 2025(PMID 40268231)进一步示证其与 GDP/GTP 两态结合后分别阻断 GEF/水解(机制细节为源文献结论)**。
- **RMC-9805(zoldonrasib)**: 靶向 **GTP(ON)态**,证据为其共晶为 GppNHp(活性类似物)结合的三复合物(PDB 9CTB)【已核实·源:PDB 配体 GNP】。
- **HRS-4642**: 摘要给出"亲和常数 0.083 nM"但未注明测定核苷酸态【已核实·源:PMID 38942026;条件缺项 → GAP】。

**关键活性数值(PubMed 转录,带 PMID)**

| 化合物 | 指标 | 数值 | 出处 |
|---|---|---|---|
| MRTX1133 | KD(GDP-KRAS G12D) | ~0.2 pM(SPR) | PMID 36216931 |
| MRTX1133 | 结合 IC50(GDP 态) | <2 nM | PMID 36216931 |
| MRTX1133 | G12D vs KRAS WT 结合选择性 | ~700× | PMID 36216931 |
| MRTX1133 | G12D 系细胞中位 IC50 | ~5 nM | PMID 36216931 |
| MRTX1133 | G12D vs WT 细胞选择性 | >1000× | PMID 36216931 |
| MRTX1133 | PDAC 模型中 ≥30% 退缩 | 8/11(73%) | PMID 36216931 |
| HRS-4642 | 亲和常数 | 0.083 nM | PMID 38942026 |
| HRS-4642 | PDAC ph1b/2 + AG,一线 cORR | 63.3%(95%CI 43.9–80.1), n=30 | PMID 42426224 |

> RMC-9805 论文(PMID 40705880)未报告可平衡 Kd(共价、酶促样速率增强),故活性谱系表不为其编造一个"等价 Kd"——这是设计使然,不是数据缺失。

---

## 4. 阶段一(续):ClinicalTrials.gov 交叉比对——三个化合物的胰腺癌注册

**检索式**:各化合物为 intervention,条件 "pancreatic"(并复核 "pancreatic ductal adenocarcinoma")。NCT 详情字段以 2026-09-04 快照为准。**(全部【已核实·源:ClinicalTrials.gov】)**

| NCT | 化合物 | 分期 | 招募状态 | 申办方 | 方案(联合用药)要点 |
|---|---|---|---|---|---|
| NCT05737706 | MRTX1133 | I | **TERMINATED** | Mirati Therapeutics | MRTX1133 单药;KRAS G12D 实体瘤队列含胰腺腺癌(完成日期字段 2025-03) |
| NCT06040541 | RMC-9805 | I | RECRUITING | Revolution Medicines | RMC-9805 单药/联合 RMC-6236;含 **PDAC** 队列 |
| NCT06445062 | RMC-9805 | I/II | RECRUITING | Revolution Medicines | GI 平台;RMC-9805±RMC-6236 + mFOLFIRINOX/5-FU 类等(多臂) |
| NCT06922591 | RMC-9805* | I/II | RECRUITING | Tango Therapeutics | RMC-9805/RMC-6236 联合 TNG462(MTAP-del)或化疗;*RMC-9805 为联合用药而非主药 |
| NCT07621718 | Zoldonrasib(RMC-9805) | **III** | RECRUITING | Revolution Medicines | **RASolute 305**:一线转移性 KRAS G12D PDAC,zoldonrasib+化疗 vs 安慰剂+化疗(奥沙利铂/5-FU/伊立替康/吉西他滨/白蛋白紫杉醇);启动 2026-05 |
| NCT05533463 | HRS-4642 | I | ACTIVE_NOT_RECRUITING | 恒瑞 | 单药,KRAS G12D 实体瘤 |
| NCT06385678 | HRS-4642 | I/II | ACTIVE_NOT_RECRUITING | 恒瑞 | KRAS G12D 实体瘤(广谱) |
| NCT06427239 | HRS-4642 | I/II | RECRUITING | 复旦大学 | **PDAC**:HRS-4642+阿德贝利单抗±SHR-8068/法米替尼/贝伐珠单抗 |
| NCT06773130 | HRS-4642 | I/II | ACTIVE_NOT_RECRUITING | 华西医院 | **PDAC**:HRS-4642+尼妥珠单抗 |
| NCT07232875 | HRS-4642 | **III** | RECRUITING | 江苏恒瑞 | **一线 KRAS G12D 胰腺癌**:HRS-4642+AG vs 安慰剂+AG |
| NCT06587061 | HRS-4642 | II | RECRUITING | 瑞金医院 | HRS-4642+AG |
| NCT07240766 | HRS-4642 | II | RECRUITING | 浙江大学 | HRS-4642+AG+尼妥珠单抗(交界可切除 PDAC) |
| NCT06770452 | HRS-4642 | II | RECRUITING | 浙江大学 | HRS-4642+尼妥珠单抗+吉西他滨+白蛋白紫杉醇 |
| NCT07296341 | HRS-4642 | I/II | RECRUITING | 上海恒瑞 | HRS-4642±阿德贝利单抗+白蛋白紫杉醇+吉西他滨 |
| NCT07131514 | HRS-4642 | II | RECRUITING | 瑞金医院 | HRS-4642+AG+阿德贝利单抗 |
| NCT07691593 | HRS-4642 | II | NOT_YET_RECRUITING | 长海医院 | HRS-4642±阿德贝利单抗+NALIRIFOX |
| NCT06938282 | HRS-4642 | II | RECRUITING | 中山医院 | HRS-4642(单药) |
| NCT06547736 | HRS-4642 | II | RECRUITING | 复旦大学 | HRS-4642 联合 SHR-A1811/A1904/A2102(ADC)±阿德贝利单抗 |
| NCT07438106 | HRS-4642 | II | RECRUITING | 南京医科大学一附院 | HRS-4642 注射剂 |

> 胰腺相关试验计数:**MRTX1133 ×1(已终止)、RMC-9805 ×4、HRS-4642 ×12**。注:其中 NCT07296341/NCT07691593/NCT06547736 为"组合方案"以平台/多臂形式录入,CSV 中 combination 字段含多臂字符串(如需按臂拆分须回到 CT.gov 原始 arm 表)。

### 4.1 交叉比对的三个事实性观察

1. **MRTX1133 临床路径已终止/搁置**(仅 NCT05737706,Phase 1/2 设计但记录状态 TERMINATED)——尽管临床前(尤其 PDAC 模型)证据最强。此状态影响"MRTX1133 临床试验"表述,须以 CT.gov 现行状态为准,而非 2022–2024 文献的 "has entered clinical trials" 表述。
2. **G12D 领域已进入注册试验阶段**:RMC-9805(RASolute 305,III 期一线 PDAC)与 HRS-4642(III 期一线 PDAC)均指向把 G12D 抑制剂推到 PDAC 一线。
3. 联合策略高度依赖**化疗骨架**(AG、mFOLFIRINOX、NALIRIFOX)与**免疫/EGFR 类/ADC**叠加;与第 7 章"耐药依赖旁路激活、需联合"的机理证据方向一致。

---

## 5. 阶段二:KRAS G12D 变异位点与危害评分

### 5.1 坐标与变异身份(【已核实·源:gnomAD v4 / v2.1,经 rs121913529 解析】)

- 转录本:KRAS canonical `ENST00000311936`(负链,chr12:25,205,246–25,250,936)
- **GRCh38**: `chr12:25,245,350 C>T` = gnomAD `12-25245350-C-T`;等位 rs121913529
- **GRCh37**: `chr12:25,398,284 C>T` = `12-25398284-C-T`
- 由于 KRAS 在负链,正链 C>T 即编码链(负链)**c.35G>A**(NM_004985)→ **p.Gly12Asp**
- 同一位点多种 alt:G12D=C>T、G12V=C>A、G12A=C>G(本表仅 C>T/G12D 展开)
- 种系等位频率(gnomAD v4):exome AF ≈ **2.74×10⁻⁶**(AC=4),genome AF ≈ 1.31×10⁻⁵——极低,与强驱动/早期致死性一致;v2.1 亦仅 1 个等位。

### 5.2 危害性评分:CADD

- **CADD 未能获取(GAP)**:连接器 `cadd_score_variant` / `cadd_score_at_position` 返回许可证错误:
  > `"variants/cadd_score_variant" is restricted to non-commercial use. Switch Settings → General → Use intent to non-commercial to enable it.`
- 未编造任何 PHRED/raw 值。若需 CADD,可在把 Use intent 切换为 non-commercial 后以 `chr12 25398284 C T (GRCh37-v1.6)` 或 `chr12 25245350 C T (GRCh38-v1.7)` 直接重算。

### 5.3 危害性代理(经核实)

| 代理指标 | 结果 | 出处 |
|---|---|---|
| ClinVar(germline 分类,GNOMAD 镜像) | **Pathogenic / Likely pathogenic;★2 星;多提交者、无冲突**;missense in ENST00000311936(variation_id 12582) | ClinVar(gnomAD mirror) |
| gnomAD 频率 | exome 2.74×10⁻⁶ | gnomAD v4 |
| KRAS 基因约束 | pLI=0.9998,oe_lof=0.048(LoF 极不耐受) | gnomAD constraint |
| 体细胞驱动共识 | PDAC 中 KRAS 突变 ~90–93%,G12D 为最常见亚型(~42–44%) | PMID 37831007 / 38686056 |

> 注:ClinVar 的 G12D 记录是**种系**分类条目;KRAS G12D 在临床上几乎只以**体细胞**致癌突变出现。上述"Pathogenic"为种系语境下的档案意义,与体细胞驱动无关——此处如实并列两个语境,避免混用。

---

## 6. 阶段二(续):对抗性测试——"MRTX1133 与 Asp12 羧基共价成键"假说审查

### 6.1 结论(先行)

> 该假说**在化学原理与结构证据上均不成立**。MRTX1133 对 KRAS G12D 是**非共价、可逆**的结合,活性位点为 Switch-II 口袋(SII-P);其突变选择性来自与 **Asp12 侧链的盐桥/离子相互作用**,而**不存在任何共价键**。学界真实的"共价靶向 G12D-Asp12"工作针对的是**别的分子与别的化学设计**(RMC-9805 的氮丙啶弹头经 CypA 催化;β-内酯/环氧/酰基重氮弹头),而非 MRTX1133 本身。

### 6.2 证据一:结构化学审查(MRTX1133 无共价弹头)【已核实·源:规范 SMILES 结构分析,可复核】

依据 3.1 的规范异构 SMILES 与 ChEMBL 分子式,MRTX1133 的功能基团集合为:芳基**末端炔**(邻位无吸电子羰基,非活化 Michael 受体)、苯酚羟基、吡啶并嘧啶、二氮杂双环与氟代吡咯里西啶(均为 sp³ 胺/醚)、芳香 C–F。**不含**任何可对羧酸根进行亲电共价反应的基团:无 Michael 受体、无 α,β-不饱和羰基、无环氧/氮丙啶/β-内酯/丙内酯、无酰基重氮、无卤代乙酰胺类离去基团。Asp 羧酸根本身是生理 pH 下**弱亲核、且在蛋白组中极为富集**的基团(见 PMID 40705880 对"低亲核性 + 高丰度羧酸"难点的说明),因此若无设计好的低活性高选择性弹头并配合近端催化,根本无法实现选择性共价修饰。结论:从分子结构上 MRTX1133 不存在可成共价键的化学通路。

### 6.3 证据二:一手论文的定性表述

- 原始发现论文标题即写明 MRTX1133 是 **"Noncovalent, Potent, and Selective KRASG12D Inhibitor"**(J Med Chem 2022)【已核实·源:PMID 34889605】,并解释:因为 G12D 不像 G12C 有可反应半胱氨酸,需要**高到足以"免除共价相互作用"的非共价亲和力**——摘要原文直译:"…the requirement of inhibitors to bind KRASG12D with high enough affinity to **obviate the need for covalent interactions** with the mutant KRAS protein."
- 体内药效论文亦题为 non-covalent,并给出可逆结合常数(KD≈0.2 pM 上界、细胞 >1000× 选择性)【已核实·源:PMID 36216931】。如此 pM 级的**可逆**亲和力本身就是非共价设计的标志;共价抑制通常表现为 kinact/KI 动力学而非平衡 KD。

### 6.4 证据三:共晶结构(PDB)【已核实·源:RCSB PDB,2026-09-04】

| PDB | 内容 | 分辨率/方法 | 配体 | 结论指向 |
|---|---|---|---|---|
| **7RPZ** | KRAS **G12D-GDP** + MRTX-1133 | 1.3 Å, X-ray | **6IC**(C33H31F3N6O2, 与游离药一致) | 完整非共价复合物;配体与游离分子式完全相同,无任何开环/加成/共价修饰迹象 |
| **7XKJ** | KRAS G12D-GDP-MRTX1133 | 3 Å, FIB-MicroED | GDP + 6IC | 同上(独立方法复现) |
| 7RT1–7RT5 等 | 系列中间体(Mirati SAR) | 1.3–1.6 Å | – | SII-P 骨架化学演化 |
| **9CTB** | **zoldonrasib(RMC-9805)+KRAS G12D+CypA** | 1.29 Å, X-ray | **GNP**(GppNHp, 激活态)+ 配体 A1AZZ | 共价 G12D 的真实结构载体:三复合物;配体呈**开环后**形式(名含 2-(methylamino)propanoyl;A1AZZ 分子式 C63H90F3N11O7,较游离药 C63H88F3N11O7 差 2 H)——与 D12 羧基亲核开环 N-甲基氮丙啶一致的方向性证据 ⓑ |
| 9QQ1 | KRAS G12D + β-内酯弹头共价复合物 | 1.3 Å | – | 需**外加高张力弹头**才能共价修饰 Asp12 |
| 7EW9 | GDP-KRAS G12D + TH-Z816 | 2.13 Å | GDP+05C | 论文标题直接:**"KRAS(G12D) can be targeted by potent inhibitors via formation of salt bridge"**——小分子经**盐桥**接触 Asp12 |

> ⓑ 直接"配体-Cys/Asp 原子间共价键"的几何应在 9CTB 结构原子坐标中查验;本报告未下载坐标文件,故以"配体开环形式 + 文献(PMID 40705880)已证共价修饰 D12"双向标注,未自行断言键长/键角。

### 6.5 证据四:反例对照——把 MRTX1133 变成共价抑制需要"外接弹头"

- 2025 J Med Chem(PMID 41017113)明确把 **酰基重氮(Acyl Diazo)弹头嫁接到 MRTX1133 骨架**上,才得到共价 TCI **KN2-H**,专门靶向 KRAS G12D。这直接反证:**MRTX1133 自身不含弹头**;研究者必须人为加装弹头才能获得共价活性。
- 另一条把 G12D 当共价靶点的路线全部自带弹头:β-内酯(malolactone,PMID 38653668 述)、环氧(oxirane,JACS PMID 37534597)、RMC-9805 的氮丙啶酰胺 + CypA 界面(PMID 40705880)。

### 6.6 假说混淆的可能来源(客观归因)

"MRTX1133 共价结合 Asp12"很可能是三件事的混淆:**(a)** KRAS **G12C** 抑制剂范式(sotorasib/adagrasib 以 Cys12 共价);**(b)** 学界确实在热烈讨论"能否共价打到 G12D 的 Asp";**(c)** 把同属 G12D 项目的 **RMC-9805 的共价机制**(D12 加成,Science 2025)误记到更早的 MRTX1133 头上。第 10 章对未能定位到的"某篇称 MRTX1133 共价的文献"做存疑登记。

### 6.7 可复核清单(供独立复核)

1. 核对 7RPZ 中配体 6IC 与 Asp12 侧链的距离(应 >3.2 Å,无共价);对比 9CTB 中 A1AZZ 与 D12 的成键。本报告因未取坐标文件而不断言,仅列出上述两结构作为判据。
2. 复核 KN2-H(PMID 41017113)与 MRTX1133 的骨架一致性(已由其摘要确认 MRTX-1133 为搭载母核)。

---

## 7. 阶段三:细胞系依赖性、KRAS 型别与耐药通路整合

### 7.1 DepMap 依赖度分数(CRISPR/Chronos)——**未能获取(GAP,重要)**

- 目标方法:`cancer_models.depmap_search_cell_line` 与 `depmap_dependencies_for_gene`(基因:KRAS、EGFR、PIK3CA、PIK3CB、PIK3R1、AKT1、AKT2、MAP2K1、BRAF、RAF1、PTPN11、ERBB2、MET)。
- 实测结果(2026-09-04,>10 次带间隔重试):**全部返回 `Error: fetch failed`**(同 server 的 cBioPortal 端点正常,可排除连接器整体故障→判定为 DepMap 源端故障)。
- **未从记忆或别处为任何细胞系-基因对填入 Chronos 数值。** CSV 中 `chronos_score` 全部为 NaN,`verified=DEPMAP-UNAVAILABLE`,并附故障说明。此为本任务最大的数据完整性缺口,在《未解析报告》中列首位。

### 7.2 经核实的替代证据:细胞系 KRAS 型别(【已核实·源:cBioPortal CCLE `ccle_broad_2019`】)

对 CCLE 中 **48 条 KRAS 突变胰腺细胞系**的亚型计数:

| KRAS 亚型 | 系数量 | 例(相关靶系) |
|---|---|---|
| **G12D** | **22** | PANC1、ASPC1、HPAC、HPAFII、KP4、SU8686、SW1990 等 |
| G12V | 17 | CAPAN1、CAPAN2、CFPAC1、PATU8988T 等 |
| G12R | 4 | HUPT3、KP2、PSN1、TCCPAN2 |
| Q61H | 2 | HS766T、T3M4 |
| G12C | 1 | **MIAPACA2(MIA PaCa-2)** |
| Q61R | 1 | PANC0213 |
| G12A | 1 | PACADD119 |

本报告聚焦的细胞系型别(经 CCLE 核实):**PANC-1=KRAS G12D、AsPC-1=KRAS G12D、MIA PaCa-2=KRAS G12C**(注意:MIA PaCa-2 是 G12C 而非 G12D;MRTX1133 面向 G12D,不能把它当 G12D 敏感对照)。HPAC、HPAF-II 亦为 G12D。

### 7.3 经核实的替代证据:MRTX1133 在 PDAC 系的细胞水平反应(活性代理依赖)

| 细胞系(型别) | MRTX1133 IC50 | 关系 | 来源 |
|---|---|---|---|
| HPAC (G12D) | 4.2 nM | = | ChEMBL activity_id 25663224 |
| AsPC-1 (G12D) | 11 nM | = | ChEMBL activity_id 25663212 |
| HPAF-II (G12D) | 14.9 nM | = | ChEMBL activity_id 25663225 |
| PANC-1 (G12D) | **>5000 nM** | > | PMID 39417197(AJCR 2024) |

> **要点**:同为 KRAS G12D,HPAC/AsPC-1/HPAF-II 对 MRTX1133 敏感(个位数~十位数 nM),而 **PANC-1 报告 >5000 nM 不敏感**——这是"突变型别 ≠ 药物依赖"的典型反例,与 DepMap 依赖度中存在的系间异质性及获得性耐药的"非突变型别决定的通路冗余"机制方向一致。此观察用于第 7.4 耐药机理讨论,但它本身是药物活性数据而非遗传依赖分数。

### 7.4 耐药通路整合(基于经核实的文献结论,逐条给 PMID)

以下为源文献明确结论的转述,非本报告推断:

- **旁路/反馈激活**:Nat Med 2022(PMID 36216931)已用药理学与 CRISPR 筛选提示"co-targeting KRASG12D with putative **feedback or bypass pathways**"可增效(摘要截断处);Cancer Biol Med 2025 综述(PMID 40624835)明确耐药由**通路再激活、继发突变、代谢适应**驱动,并建议与 **MEK、PI3K、CDK4/6、SHP2/SOS1(上游)** 联用——其中 **PI3K 通路富集倾向**亦在 Thoracic Cancer 2025 综述(PMID 41423807)被点名(G12D 缺乏反应性位点、倾向激活 PI3K/AKT 并塑造免疫抑制微环境)。
- **继发突变/二次突变**:PDB 已收录 MRTX1133 的"KRAS secondary mutation-conferred resistance"结构工作(9U8Y 等,标题 "Molecule Mechanisms of KRAS Secondary Mutation Conferred Resistance of MRTX1133")【已核实·源:PDB 记录,论文 DOI 未在 PDB 头文件给出→作为条目登记】。
- **代谢/凋亡代偿**:MRTX1133 上调促凋亡 BIM 并增敏 BCL2 抑制剂 venetoclax;venetoclax 可部分**逆转 MRTX1133 耐药系**(PMID 39137400);KRAS G12D 重塑 PPP 代谢并可通过 UBE2T 轴介导耐药(PMID 39970873)。HRS-4642 的 CRISPR 增敏/耐药谱把 **蛋白酶体**列为增敏靶点(PMID 38942026)。
- 整合含义:G12D 抑制剂的耐药不限于 RAS 信号单一轴线,RTK 旁路(EGFR 族/ADC 联合见临床方案)、PI3K/AKT、MEK、代谢与凋亡闸门都是联合/耐药管理的候选枢纽。**DepMap 若可恢复,应按第 10 章补测表直接在 KRAS/EGFR/PI3K 节点上加总验证上述推断;当前缺该基因效应矩阵。**

---

## 8. 阶段四:图表方法与产出清单

### 8.1 `kras_figure.png`(300 dpi,另存矢量 `kras_figure.svg`)

- **Panel A**:CCLE 胰腺 KRAS 突变细胞系亚型计数横条(n=48;G12D 22 以主题色标出,余灰);来源脚注 cBioPortal ccle_broad_2019。
- **Panel B**:MRTX1133 在 KRAS 突变 PDAC 系的 IC50(nM,log10 轴)点图:HPAC 4.2 / AsPC-1 11 / HPAF-II 14.9(实心点),PANC-1(G12D 但体外不敏感)**>5000 nM 阈值标记**(空心三角,保留 ">" 关系),虚线 = 文献 G12D 系中位 IC50 ≈5 nM(Nat Med 2022)。色彩线程:G12D 在两面板使用同一蓝;图内脚注明示 DepMap 缺口未绘制。
- **图注与保留关系**:阈值读数以 ">" 表达、绝不当精确值;图中对 PANC-1 标注 PMID 39417197。

### 8.2 figure_review 检查记录

- **工具故障登记(GAP)**:调用内置 `figure_review` 两次均返回服务端错误 `Figure review RPC params must include sessionId, projectId, and request.`(与面板内容无关,重试未果)。**未能运行工具化检查**。
- **替代:人工逐条执行同源五规则**(渲染图经目检,第一版 PANC-1 标签越界与脚注出界问题已在第二版修正并复检):
  1. 数据保真:无剔除行渗入汇总;PANC-1 保持 ">" 关系不当作精确值;中位参考线单独标注来源。
  2. 标签经济:两面板轴均有标签;值标注与点不碰撞(复检通过)。
  3. 色彩线程:G12D 在 A/B 两面板恒为同一蓝(#0F6BFF),非 G12D 灰,调色板可分。
  4. 图表匹配数据形:类别计数→条;量值随类别→对数点图(刻意规避 log 基线柱的误导)。
  5. 渲染核查:PNG 目检确认无裁剪、无遮挡。

### 8.3 交付产物清单

| 文件 | 说明 | 状态 |
|---|---|---|
| `kras_g12d_multimodal_dossier.md` | 本报告 | 本次交付 |
| `merged_kras_evidence.csv` | 清洗整合表(121 行,4 域,含 verified/source 列) | 本次交付 |
| `kras_figure.png`(+`.svg`) | 出版级图 | 本次交付 |
| `01_build_merged_evidence.py` / `02_make_kras_figure.py` | 可复现脚本 | 本次交付 |
| `intermediate/*.json`(10 个) | 不可变 Connector 快照 | 本次交付 |

---

## 9. 引用来源(全部经本报告执行过程实时核验)

**Primary papers(PubMed)**
1. Hallin J, et al. *Nat Med* 2022. "Anti-tumor efficacy of a potent and selective non-covalent KRASG12D inhibitor." DOI 10.1038/s41591-022-02007-7 — PMID 36216931
2. Wang X, et al.(Mirati)*J Med Chem* 2022. "Identification of MRTX1133, a Noncovalent, Potent, and Selective KRASG12D Inhibitor." DOI 10.1021/acs.jmedchem.1c01688 — PMID 34889605
3. Koltun E, et al. *Science* 2025. "A neomorphic protein interface catalyzes covalent inhibition of RASG12D aspartic acid in tumors." DOI 10.1126/science.ads0239 — PMID 40705880
4. Zhou C, et al. *Cancer Cell* 2024. "Anti-tumor efficacy of HRS-4642 … KRAS G12D-mutant cancer." DOI 10.1016/j.ccell.2024.06.001 — PMID 38942026
5. *Nat Med* 2026. "KRAS-G12D inhibitor HRS-4642 plus chemotherapy in advanced KRASG12D-mutant pancreatic cancer: a phase 1b/2 trial." DOI 10.1038/s41591-026-04538-9 — PMID 42426224
6. *J Med Chem* 2025. "Expanding the Chemistry of Acyl Diazo Electrophile … Covalent Targeting of KRAS (G12D) Mutant."(KN2-H)DOI 10.1021/acs.jmedchem.5c01365 — PMID 41017113
7. *JACS* 2023. "Simultaneous Covalent Modification of K-Ras(G12D) and K-Ras(G12C) with Tunable Oxirane Electrophiles." DOI 10.1021/jacs.3c05899 — PMID 37534597
8. *Trends Pharmacol Sci* 2024(述 Zheng et al Nat Chem Biol 的 malolactone 弹头)。DOI 10.1016/j.tips.2024.04.001 — PMID 38653668
9. Kemper S, et al. *Cancer Res* 2024(venetoclax 增敏/逆转耐药)。DOI 10.1158/0008-5472.CAN-23-3574 — PMID 39137400
10. *Cell Rep Med* 2025(PPP/UBE2T 耐药轴)。DOI 10.1016/j.xcrm.2025.101966 — PMID 39970873
11. *J Mol Biol* 2025. "Switch II Pocket Inhibitor Allosterically Freezes KRASG12D …" DOI 10.1016/j.jmb.2025.169162 — PMID 40268231
12. *Cancer Biol Med* 2025 综述。DOI 10.20892/j.issn.2095-3941.2025.0122 — PMID 40624835
13. *Thoracic Cancer* 2025 综述。DOI 10.1111/1759-7714.70203 — PMID 41423807
14. *Cell Discov* 2022(盐桥,TH-Z816 系列)。DOI 10.1038/s41421-021-00368-w(经 PDB 7EW9 引证)
15. *Clin Cancer Res* 2024(PDAC KRAS 突变谱评述)。DOI 10.1158/1078-0432.CCR-23-2098 — PMID 37831007
16. *Oncol Res* 2024(PDAC KRAS 亚型分布)。DOI 10.32604/or.2024.045356 — PMID 38686056
17. *Am J Cancer Res* 2024(MRTX1133 系间 IC50,含 PANC-1 >5000)。DOI 10.62347/DVXL1377 — PMID 39417197

**结构(PDB)**：7RPZ、7XKJ、9CTB、9QQ1、7EW9、7RT1–7RT5、8EZG、9U8Y 等(详见 6.4 表)

**标识符数据库**：ChEMBL CHEMBL4858364 / CHEMBL5081048;PubChem CID 156124857 / 168201327 / 171853615;rs121913529(GRCh37 12-25398284-C-T、GRCh38 12-25245350-C-T)

**临床试验(ClinicalTrials.gov)**：见第 4 章表(17 个 NCT)

**细胞系/变异**：cBioPortal CCLE `ccle_broad_2019`;gnomAD v4/v2.1;ClinVar variation_id 12582

---

## 10. 《未解析/数据源冲突报告》

本节只列"想要但没拿到 / 拿到了但可疑 / 两源打架"的条目,每条给状态、证据、影响与可修复路径。

### 10.1 重要缺口
| # | 缺口 | 状态/证据 | 影响 | 修复路径 |
|---|---|---|---|---|
| R1 | **DepMap Chronos 基因效应分数未获取** | `cancer_models.depmap_search_cell_line`/`depmap_dependencies_for_gene` 全程 `Error: fetch failed`(同 server cBioPortal 正常,判定 DepMap 源端故障;>10 次重试) | 阶段三"依赖度对比表"的数值本体缺失;图表与 CSV 未包含任何基因效应值 | DepMap 恢复后按 `merged_kras_evidence.csv` 中 48 系清单批量补取 KRAS/EGFR/PI3K 节点基因;脚本预留列 |
| R2 | **CADD PHRED/raw 未获取** | 连接器报 non-commercial 许可限制(记录见 5.2) | "危害评分"只能以 ClinVar/gnomAD/约束做代理 | 在 Settings→General 将 Use intent 切为 non-commercial 后重跑:GRCh37 `12-25398284 C>T` / GRCh38 `12-25245350 C>T` |
| R3 | RMC-9805 与 HRS-4642 **在 ChEMBL 无条目**(名字检索 total=0,含 RMC-6236/7977/6291/JAB-22000/GFH375 等探针对照) | ChEMBL compound_search 返回 0 | 两化合物的"ChEMBL 结构+活性"无法满足;以 PubChem(CID/分子式/SMILES)+ PubMed 活性替代 | ChEMBL 后续 release 收录后回填;当前保持 PubChem 通道标注 |
| R4 | **figure_review 工具未运行成功** | 两次调用均服务端报 `Figure review RPC params must include sessionId, projectId, and request.` | 缺工具化规则报告;改以人工执行同源五规则(见 8.2) | 待该 RPC 参数注入修复后对成品 PNG 重跑 |

### 10.2 可疑/低置信条目(需复核)
| # | 条目 | 证据与存疑点 |
|---|---|---|
| R5 | MRTX1133 KD ≈ 0.2 pM | 一手文献与 ChEMBL 关系符 `<0.0002 nM` 一致,但 0.2 pM 处于 SPR 灵敏度下限(ChEMBL 用 "<")。**保留为上界量级**;勿当作高精度 Kd。 |
| R6 | ChEMBL 若干行靶点名称为 "Unchecked"(target CHEMBL612545) | 经本工具集无法解析该 target 实体身份(疑为细胞系/报告板实体)。行内数值(如 Kd<0.0002、IC50 2–6500 nM 高值行)真实存在,但其宿主细胞系/条件无法在此解析→**高值不敏感行的具体归属(G12D 系 vs 耐药系 vs 无关系)未能确认**,不要与"PANC-1"直接等同。 |
| R7 | ChEMBL document↔PMID 映射 | 工具集无 ChEMBL doc 查询;doc CHEMBL5143589(含 0.2 pM Kd 与 <2 nM 行)疑为 Nat Med 2022 的沉积,但**未在工具内直接证实**;文中已以 PMID 摘要独立转录数值,故结论不受影响,映射本身存疑登记。 |
| R8 | PDAC 亚型百分比两处略异 | CCR 2024(PMID 37831007)G12D≈42%/G12V≈32%;Oncol Res 2024(PMID 38686056)G12D≈44%/G12V≈34%/G12R≈20%。来源队列不同,并列呈现,不做唯一化。 |
| R9 | MIA PaCa-2 对 MRTX1133 的**精确** IC50 无直接来源 | 本报告检索到的来源未给出该 G12C 系的具体数值(仅给 "G12D vs WT >1000×" 与系间大范围)。图/表中不为其填数;如需可回查 Hallin 2022 补充表。 |
| R10 | PDB 9CTB 配体 A1AZZ 分子式 C63H90F3N11O7 vs PubChem 游离 zoldonrasib C63H88F3N11O7 差 2 H | 方向性与"氮丙啶开环"一致,但 PDB 沉积配体与其结合态质子化/开环细节需坐标级核验(未下载坐标)。已按"结构性方向证据"标注,未升级为"已证实键合"。 |
| R11 | NCT06922591 以 RMC-9805 命中但**申办方为 Tango**,RMC-9805 为其平台联合用药 | 交叉比对时归入 RMC-9805 的胰腺相关试验会误导读者为 Revolution 主办;CSV 中 sponsor 字段已保留原始(Tango),解读时应区分主药与联合方。 |
| R12 | MRTX1133 临床状态表述的"文献 vs 注册库"冲突 | 2022–2024 文献常写 MRTX1133 "has entered clinical trials";CT.gov 现行记录 NCT05737706 为 **TERMINATED**(完成日期字段 2025-03)。本报告以注册库现行状态为准,并保留文献表述差异于 4.1 中说明。 |
| R13 | 数条 HRS-4642 试验为"平台/多臂"式录入 | combination 字段含多臂字符串(NCT07296341/NCT07691593/NCT06547736 等),按臂拆分须回 CT.gov 原始 arm 设计;CSV 未拆分。 |

### 10.3 明确"数据分页/截断"登记
- ClinicalTrials 检索对每化合物×(condition)设置了 `page_size=50` 且 `count_total=true`;各返回均未截断(`truncated=false`),计数可靠。但"胰腺相关"用 Essie 同义词扩展,个别宽泛命中(如平台型试验)已按 NCT 级别逐一核实条件字段。
- ChEMBL MRTX1133 活性按单页拉取(limit=100),`total=45` 全部获取,无分页截断。
- cBioPortal CCLE KRAS 突变:一次取 235 条突变(223 个突变系)无截断(`max_records` 足够);胰腺系过滤后 48 系。
- PDB text 检索 "KRAS G12D" total=142 且截断(n=60 取回)→ 该检索仅作定位用途,用于判读的具体结构(7RPZ 等)均为精确定位、无截断影响。
- PubMed 各检索按 relevance 取前 12 条;`total_count` 均已记录(mrtx1133=156 等)。凡未展开的命中仅用于定位主文献。

---

*报告结束。数据快照与脚本均保留于本次会话产物;任何数值均可由 `intermediate/*.json` + 文内 PMID/NCT/PDB/activity_id 逐步回放验证。*
