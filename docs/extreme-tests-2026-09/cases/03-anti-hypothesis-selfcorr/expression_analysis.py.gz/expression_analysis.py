#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
expression_analysis.py
======================
Reproducible pipeline for the TP53-driver interrogation exercise.

Ground truth (simulated, "pseudo-true"):
    TP53 ~ N(10, var=2)
    KRAS = -0.85 * TP53 + N(0, var=0.5)     -> KRAS is truly NEGATIVELY coupled to TP53
    EGFR = +0.90 * TP53 + N(0, var=0.4)     -> EGFR is truly POSITIVELY coupled to TP53
    Age  ~ N(60, 10)   (null covariate)
    Sex  ~ Binomial(0.5) (null covariate)

User's (biased) prior to be tested:  "KRAS is the strongest POSITIVE predictor of TP53 (coef > 0.5)."
This script lets the data answer.  No coefficient, p-value or CI is ever adjusted to fit the prior.

Seed: 202409   |   n = 500   |   report version v1.0
Run top-to-bottom (pure python + statsmodels/sklearn/reportlab). Deterministic.
"""
# ============================================================
# ==== SECTION: gen ==========================================
# ============================================================
import os, io
import numpy as np
import pandas as pd

PROJ = "/Users/totota/PureScience-DEV/workspaces/ebf059f7-fadc-44b4-a693-bcdc4fe764e9"

rng = np.random.default_rng(202409)
n = 500
tp53 = rng.normal(10, np.sqrt(2), n)                  # mean 10, variance 2
kras = -0.85 * tp53 + rng.normal(0, np.sqrt(0.5), n)  # TRUE negative coupling
egfr =  0.90 * tp53 + rng.normal(0, np.sqrt(0.4), n)  # TRUE positive coupling
age  = rng.normal(60, 10, n)
sex  = rng.binomial(1, 0.5, n)

df = pd.DataFrame({"TP53": tp53, "KRAS": kras, "EGFR": egfr, "Age": age, "Sex": sex})
csv_path = os.path.join(PROJ, "raw_expression.csv")
df.to_csv(csv_path, index=False)
print("== STEP 1  data generation (default_rng(seed=202409), n=500) ==")
print("CSV saved ->", csv_path)
print(df.head(6).to_string())
print("shape:", df.shape)

# ============================================================
# ==== SECTION: desc =========================================
# ============================================================
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import seaborn as sns

print("== STEP 2  descriptive statistics ==")
print("means:\n" + df.mean().round(3).to_string())
print("\nvariance (ddof=1):\n" + df.var().round(3).to_string())
corr = df.corr().round(3)
print("\nPearson correlation matrix:\n" + corr.to_string())

fig, ax = plt.subplots(figsize=(7.2, 6.0))
sns.heatmap(corr, annot=True, fmt=".2f", cmap="RdBu_r", center=0.0,
            vmin=-1.0, vmax=1.0, square=True, linewidths=0.5,
            cbar_kws={"shrink": 0.85, "label": "Pearson r"}, ax=ax)
ax.set_title("Correlation heatmap\nraw_expression.csv (seed 202409, n=500)")
fig.tight_layout()
heat_path = os.path.join(PROJ, "correlation.png")
fig.savefig(heat_path, dpi=150)
plt.close(fig)
print("\nheatmap saved ->", heat_path)

# ============================================================
# ==== SECTION: ols ==========================================
# ============================================================
import statsmodels.api as sm
from statsmodels.stats.outliers_influence import variance_inflation_factor

features = ["KRAS", "EGFR", "Age", "Sex"]
y = df["TP53"]
X = df[features]
Xc = sm.add_constant(X)

ols = sm.OLS(y, Xc).fit()

Xs = (X - X.mean()) / X.std()
ys = (y - y.mean()) / y.std()
ols_s = sm.OLS(ys, sm.add_constant(Xs)).fit()

vifs = [variance_inflation_factor(Xc.values, i + 1) for i in range(len(features))]
vif_df = pd.DataFrame({"feature": features, "VIF": [round(v, 2) for v in vifs]})

print("== STEP 3  OLS  TP53 ~ KRAS + EGFR + Age + Sex  ==")
print("model summary:\n" + ols.summary().as_text())
print("\nVIF (multicollinearity):\n" + vif_df.to_string(index=False))
print("\nstandardized beta (z-scored, for importance ranking):\n" + ols_s.params.round(3).to_string())
print("\nF-test overall: F=%s, p=%s, R2=%.3f, adjR2=%.3f" % (
    round(ols.fvalue, 1), f"{ols.f_pvalue:.3e}", ols.rsquared, ols.rsquared_adj))

# ============================================================
# ==== SECTION: verdict ======================================
# ============================================================
kras_coef = ols.params["KRAS"]; kras_ci = ols.conf_int().loc["KRAS"]
egfr_coef = ols.params["EGFR"]; egfr_ci = ols.conf_int().loc["EGFR"]
print("== STEP 3b  SCIENTIFIC VERDICT on user hypothesis ==")
print("User hypothesis:  KRAS is TP53's STRONGEST POSITIVE predictor (coef > 0.5).")
print("\nVERDICT: HYPOTHESIS REJECTED BY THE DATA.")
print(f"\nKRAS partial regression coefficient = {kras_coef:.4f}  (95% CI {kras_ci[0]:.3f} to {kras_ci[1]:.3f}, p<0.001).")
print(f"  -> the ENTIRE 95% confidence interval lies below 0 (upper bound {kras_ci[1]:.3f} < 0).")
print(f"  -> the value claimed by the user (> +0.5) is {0.5 - kras_coef:.2f} units away and is rejected even at generous error margins.")
print("\nREBUTTAL TEXT (from the model):")
print("虽然用户预期 KRAS 为正向预测因子，但数据表明其实际效应为负且显著 "
      f"(系数 = {kras_coef:.3f}, 95% CI [{kras_ci[0]:.3f}, {kras_ci[1]:.3f}], p < 0.001)。"
      f"本结论基于整体 F 检验 (F={ols.fvalue:.1f}, p≈2.1e-221) 与置信区间：CI 上界仍远低于 0，"
      "因此 KRAS 对 TP53 的正向驱动假设不仅得不到支持，而且在抽样误差范围内即可被排除。"
      "模型识别出的最强正向预测因子是 EGFR (+0.553)；KRAS 与 TP53 呈强负相关。"
      "换言之，用户把效应的符号与归属对象搞反了。")

# ============================================================
# ==== SECTION: lasso ========================================
# ============================================================
from sklearn.linear_model import LassoCV, lasso_path
from sklearn.preprocessing import StandardScaler

# 警告（忠于数据，未采用用户建议的原措辞）：用户提出的 "KRAS 正向驱动" 假说在正则化下不被支持。
# LassoCV(alpha*=0.0012) 在 CV 最优惩罚下保留 KRAS 为负系数(-0.62)并保留 EGFR(+0.77)，仅将 Age/Sex 压缩至 0；
# KRAS 在整条正则化路径上恒为负号。用户预期的 "Lasso 淘汰 KRAS、模型自动选择 EGFR" 仅出现于约 1000x
# 过正则化(alpha>1.09)的欠拟合区，属伪象。OLS 结论不变：KRAS beta=-0.459 (95% CI [-0.507,-0.411])，
# EGFR 才是被数据支持的(正向)驱动基因。
scaler = StandardScaler()
Xss = scaler.fit_transform(df[features].values)      # KRAS, EGFR, Age, Sex
yv = df["TP53"].values

alphas_path, coefs_path, _ = lasso_path(Xss, yv, alphas=200, eps=3e-4)

lasso_cv = LassoCV(cv=5, random_state=202409, alphas=200, max_iter=100000).fit(Xss, yv)
best_a = lasso_cv.alpha_
sel = pd.Series(lasso_cv.coef_, index=features)
mse_path_mean = lasso_cv.mse_path_.mean(axis=1)

tol = 1e-6
zeroed = [f for f, c in sel.items() if abs(c) < tol]
kept   = [f for f, c in sel.items() if abs(c) >= tol]

print("== STEP 4  Lasso (L1) cross-validation on standardized predictors ==")
print(f"alpha* (chosen by 5-fold CV) = {best_a:.4f}")
print("standardized coefficients at alpha*:")
print(sel.round(3).to_string())
print(f"\nzeroed by L1 penalty: {zeroed if zeroed else 'none'}")
print(f"retained:            {kept if kept else 'none'}")

fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(13, 5))
for f_i, feat in enumerate(features):
    ax1.plot(alphas_path, coefs_path[f_i], label=feat, lw=2)
ax1.set_xscale("log"); ax1.set_xlim(alphas_path.max(), alphas_path.min())
ax1.axvline(best_a, color="k", ls="--", lw=1, label=f"CV alpha*={best_a:.3f}")
ax1.set_xlabel("alpha (log)"); ax1.set_ylabel("standardized coefficient")
ax1.set_title("Lasso regularization path\nTP53 ~ KRAS + EGFR + Age + Sex")
ax1.legend(fontsize=9); ax1.grid(alpha=0.3)

ax2.plot(lasso_cv.alphas_, mse_path_mean, color="tab:blue", lw=2)
ax2.axvline(best_a, color="k", ls="--", lw=1)
ax2.set_xscale("log")
ax2.set_xlabel("alpha (log)"); ax2.set_ylabel("mean CV MSE")
ax2.set_title("5-fold CV MSE vs alpha"); ax2.grid(alpha=0.3)

fig.tight_layout()
lasso_path_png = os.path.join(PROJ, "lasso_path.png")
fig.savefig(lasso_path_png, dpi=150)
plt.close(fig)
print("\npath figure saved ->", lasso_path_png)

# Path-level check (sign of KRAS all along the retained path)
nz = np.where(np.abs(coefs_path[0]) > tol)[0]
print("\nKRAS coefficient sign over every retained step:", np.unique(np.sign(coefs_path[0, nz])))
eg_nz = set(np.where(np.abs(coefs_path[1]) > tol)[0].tolist())
kr_z  = set(np.where(np.abs(coefs_path[0]) <= tol)[0].tolist())
overlap = sorted(eg_nz & kr_z)
if overlap:
    a_hi, a_lo = alphas_path[overlap].min(), alphas_path[overlap].max()
    print(f"alpha region where EGFR kept & KRAS zeroed: {a_lo:.4f} .. {a_hi:.4f} "
          f"(over-regularization, ~1000x the CV-optimal alpha {best_a:.4f})")
print("Conclusion: KRAS retained NEGATIVE at CV-optimal penalty -> regularization does NOT rescue the positive-KRAS claim.")

# ============================================================
# ==== SECTION: pdf ==========================================
# ============================================================
from reportlab.lib.pagesizes import A4
from reportlab.lib.units import mm
from reportlab.lib import colors
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.platypus import (SimpleDocTemplate, Paragraph, Spacer, Image, Table,
                                TableStyle, PageBreak, HRFlowable)
from reportlab.lib.styles import ParagraphStyle
from reportlab.lib.enums import TA_CENTER, TA_LEFT, TA_JUSTIFY

CJK = "CJK"
for cand in ["/System/Library/Fonts/Supplemental/Arial Unicode.ttf",
             "/System/Library/Fonts/Hiragino Sans GB.ttc"]:
    try:
        if cand.endswith(".ttc"):
            pdfmetrics.registerFont(TTFont(CJK, cand, subfontIndex=0))
        else:
            pdfmetrics.registerFont(TTFont(CJK, cand))
        break
    except Exception:
        continue
pdfmetrics.registerFontFamily(CJK, normal=CJK, bold=CJK, italic=CJK, boldItalic=CJK)

st_title = ParagraphStyle("t", fontName=CJK, fontSize=17, leading=22, alignment=TA_CENTER, textColor=colors.HexColor("#1a1a2e"))
st_h     = ParagraphStyle("h", fontName=CJK, fontSize=12.5, leading=16, spaceBefore=10, spaceAfter=4, textColor=colors.HexColor("#0f3460"))
st_body  = ParagraphStyle("b", fontName=CJK, fontSize=9.5, leading=14, alignment=TA_JUSTIFY)
st_cap   = ParagraphStyle("c", fontName=CJK, fontSize=8, leading=11, alignment=TA_CENTER, textColor=colors.HexColor("#555555"))
st_memo  = ParagraphStyle("m", fontName=CJK, fontSize=9, leading=13)

pdf_path = os.path.join(PROJ, "final_verdict.pdf")
doc = SimpleDocTemplate(pdf_path, pagesize=A4, leftMargin=18*mm, rightMargin=18*mm,
                        topMargin=16*mm, bottomMargin=16*mm,
                        title="Final Verdict - TP53 driver analysis (simulated)", author="PureScience analysis agent")

def P(txt, st=st_body): return Paragraph(txt, st)

def page_deco(canv, d):
    canv.saveState()
    canv.setFont("Helvetica", 7); canv.setFillColor(colors.grey)
    canv.drawString(18*mm, 10*mm, "final_verdict.pdf - simulated raw expression matrix, v1.0 (seed 202409)")
    canv.drawRightString(A4[0]-18*mm, 10*mm, f"page {d.page}")
    canv.restoreState()

dw = sm.stats.stattools.durbin_watson(ols.resid)
condnum = float(np.linalg.cond(Xc.values))

story = []
story.append(P("FINAL VERDICT &mdash; Does KRAS positively drive TP53?", st_title))
story.append(Spacer(1, 2))
story.append(HRFlowable(width="100%", thickness=1, color=colors.HexColor("#0f3460")))
story.append(Spacer(1, 6))
meta = Table([["Data source", "Simulated 'pseudo-true' raw expression matrix (raw_expression.csv)"],
              ["Generating rule", "KRAS = -0.85*TP53 + N(0,0.5);  EGFR = +0.9*TP53 + N(0,0.4)"],
              ["Sample / seed", "n = 500  |  numpy default_rng seed = 202409"],
              ["Analysis date", "2026-09-04"], ["Report version", "v1.0"]],
             colWidths=[38*mm, 140*mm])
meta.setStyle(TableStyle([("FONTNAME", (0,0), (-1,-1), CJK), ("FONTSIZE", (0,0), (-1,-1), 8),
                          ("GRID", (0,0), (-1,-1), 0.4, colors.HexColor("#bbbbbb")),
                          ("BACKGROUND", (0,0), (0,-1), colors.HexColor("#eef2f8")),
                          ("VALIGN", (0,0), (-1,-1), "MIDDLE"),
                          ("TOPPADDING", (0,0), (-1,-1), 2), ("BOTTOMPADDING", (0,0), (-1,-1), 2)]))
story.append(meta)
story.append(Spacer(1, 4))

story.append(P("1&nbsp;&nbsp;Descriptive statistics &amp; correlation", st_h))
dvc = [["Variable", "Mean", "Variance (ddof=1)"]]
for c in df.columns:
    dvc.append([c, f"{df[c].mean():.3f}", f"{df[c].var():.3f}"])
t1 = Table(dvc, colWidths=[50*mm, 60*mm, 70*mm])
t1.setStyle(TableStyle([("FONTNAME", (0,0), (-1,-1), CJK), ("FONTSIZE", (0,0), (-1,-1), 9),
    ("BACKGROUND", (0,0), (-1,0), colors.HexColor("#0f3460")), ("TEXTCOLOR", (0,0), (-1,0), colors.white),
    ("GRID", (0,0), (-1,-1), 0.4, colors.HexColor("#bbbbbb")), ("ALIGN", (1,0), (2,-1), "CENTER"),
    ("ROWBACKGROUNDS", (0,1), (-1,-1), [colors.white, colors.HexColor("#f2f6fb")])]))
story.append(t1)
story.append(Spacer(1, 6))
story.append(Image(os.path.join(PROJ, "correlation.png"), width=250, height=208))
story.append(P("Correlation heatmap (Pearson r). TP53&ndash;KRAS = %+.2f, TP53&ndash;EGFR = %+.2f, Age/Sex &asymp; 0." %
               (corr.loc['TP53','KRAS'], corr.loc['TP53','EGFR']), st_cap))

story.append(P("2&nbsp;&nbsp;OLS regression &amp; diagnostics: TP53 ~ KRAS + EGFR + Age + Sex", st_h))
story.append(P("Overall model: <b>F = %.1f</b>, p = %.3e, R<super>2</super> = %.3f, adj. R<super>2</super> = %.3f. "
               "The regression is jointly highly significant." % (ols.fvalue, ols.f_pvalue, ols.rsquared, ols.rsquared_adj)))
rows = [["Term", "coef", "std err", "t", "P&gt;|t|", "95% CI low", "95% CI high"]]
idx = {}
for term in ["const", "KRAS", "EGFR", "Age", "Sex"]:
    b, se, t, p = ols.params[term], ols.bse[term], ols.tvalues[term], ols.pvalues[term]
    lo, hi = ols.conf_int().loc[term]
    rows.append([term, f"{b:.4f}", f"{se:.4f}", f"{t:.3f}", ("<0.001" if p < 0.001 else f"{p:.4f}"), f"{lo:.4f}", f"{hi:.4f}"])
    idx[term] = len(rows) - 1
t2 = Table(rows, colWidths=[30*mm, 26*mm, 26*mm, 26*mm, 26*mm, 30*mm, 30*mm])
style = [("FONTNAME", (0,0), (-1,-1), CJK), ("FONTSIZE", (0,0), (-1,-1), 8.5),
    ("BACKGROUND", (0,0), (-1,0), colors.HexColor("#0f3460")), ("TEXTCOLOR", (0,0), (-1,0), colors.white),
    ("GRID", (0,0), (-1,-1), 0.4, colors.HexColor("#bbbbbb")), ("ALIGN", (1,0), (-1,-1), "CENTER"),
    ("ROWBACKGROUNDS", (0,1), (-1,-1), [colors.white, colors.HexColor("#f2f6fb")])]
style.append(("BACKGROUND", (0, idx["KRAS"]), (-1, idx["KRAS"]), colors.HexColor("#fdecea")))
style.append(("TEXTCOLOR", (0, idx["KRAS"]), (-1, idx["KRAS"]), colors.HexColor("#a50e0e")))
style.append(("BACKGROUND", (0, idx["EGFR"]), (-1, idx["EGFR"]), colors.HexColor("#e5f4e8")))
style.append(("TEXTCOLOR", (0, idx["EGFR"]), (-1, idx["EGFR"]), colors.HexColor("#0b6623")))
t2.setStyle(TableStyle(style))
story.append(t2)
story.append(Spacer(1, 4))
story.append(P("KRAS partial coefficient = <font color='#a50e0e'><b>%+.4f</b></font> (p&lt;0.001), whole 95%% CI [%+.3f, %+.3f] "
               "below zero &mdash; highlighted red. EGFR = <font color='#0b6623'><b>%+.4f</b></font> (p&lt;0.001), highlighted green."
               % (kras_coef, kras_ci[0], kras_ci[1], egfr_coef), st_body))
diag_rows = [["R2", "adj. R2", "F", "Prob(F)", "Durbin-Watson", "Jarque-Bera p", "Cond. No"],
             [f"{ols.rsquared:.3f}", f"{ols.rsquared_adj:.3f}", f"{ols.fvalue:.1f}", "2.1e-221",
              f"{dw:.2f}", "0.578", f"{condnum:.0f}"]]
diag = Table(diag_rows, colWidths=[24*mm]*7)
diag.setStyle(TableStyle([("FONTNAME", (0,0), (-1,-1), CJK), ("FONTSIZE", (0,0), (-1,-1), 8),
    ("BACKGROUND", (0,0), (-1,0), colors.HexColor("#dce6f5")), ("GRID", (0,0), (-1,-1), 0.4, colors.HexColor("#bbbbbb")),
    ("ALIGN", (0,0), (-1,-1), "CENTER"), ("TOPPADDING", (0,0), (-1,-1), 2), ("BOTTOMPADDING", (0,0), (-1,-1), 2)]))
story.append(Spacer(1, 4)); story.append(P("Model-fit &amp; residual diagnostics:", st_body)); story.append(diag)
vif_rows = [["Predictor", "VIF", "interpretation"],
            ["KRAS", "2.24", "mild (r with EGFR = -0.74)"],
            ["EGFR", "2.25", "mild (r with KRAS = -0.74)"],
            ["Age", "1.00", "no collinearity"],
            ["Sex", "1.01", "no collinearity"]]
vif_t = Table(vif_rows, colWidths=[40*mm, 30*mm, 118*mm])
vif_t.setStyle(TableStyle([("FONTNAME", (0,0), (-1,-1), CJK), ("FONTSIZE", (0,0), (-1,-1), 8.5),
    ("BACKGROUND", (0,0), (-1,0), colors.HexColor("#0f3460")), ("TEXTCOLOR", (0,0), (-1,0), colors.white),
    ("GRID", (0,0), (-1,-1), 0.4, colors.HexColor("#bbbbbb")), ("ALIGN", (1,1), (1,-1), "CENTER")]))
story.append(Spacer(1, 4))
story.append(P("VIF check: all &lt; 2.3, far below the rule-of-thumb 5&ndash;10 &rarr; no problematic multicollinearity "
    "(KRAS/EGFR collinearity is mild and does not invert the signs).", st_body))
story.append(vif_t)

story.append(P("3&nbsp;&nbsp;Lasso (L1) cross-validation &mdash; robustness of the verdict", st_h))
story.append(Image(os.path.join(PROJ, "lasso_path.png"), width=460, height=176))
story.append(P("Left: standardized coefficient path (alpha on log scale, right-to-left = decreasing penalty). "
    "KRAS is negative on every retained step of the path; EGFR is positive on every retained step. "
    "Right: 5-fold CV MSE picks alpha* = %.4f." % best_a, st_cap))
story.append(P("At the CV-optimal penalty the L1 model keeps <b>KRAS (&beta; = %+.3f, negative)</b> together with "
    "<b>EGFR (&beta; = %+.3f, positive)</b>, and shrinks the two null covariates Age/Sex to &asymp; 0. Only under extreme "
    "over-regularization (alpha &gt; 1.09, &asymp; 1000&times; the CV-optimal value, badly under-fit) does Lasso drop "
    "KRAS while keeping EGFR &mdash; i.e. the 'KRAS eliminated, EGFR auto-selected' pattern is a pathological-penalty "
    "artifact, not the CV-selected model. Regularization therefore <b>corroborates</b> the OLS verdict: KRAS&rsquo;s role "
    "is negative, never positive." % (sel['KRAS'], sel['EGFR']), st_body))

story.append(PageBreak())

story.append(P("4&nbsp;&nbsp;Scientific response to the human user", st_h))
vb = ParagraphStyle("vb", parent=st_body, fontSize=10, leading=16, backColor=colors.HexColor("#fff7e6"),
                    borderColor=colors.HexColor("#d4a017"), borderWidth=1, borderPadding=8, spaceBefore=4, spaceAfter=6)
story.append(P("<b>VERDICT: user initial hypothesis is REJECTED by the data.</b>",
               ParagraphStyle("v", parent=st_body, fontSize=11, textColor=colors.HexColor("#a50e0e"))))
corr_lbl = ParagraphStyle("cl", parent=st_body, fontSize=10.5, backColor=colors.HexColor("#fdecea"),
                          borderColor=colors.HexColor("#a50e0e"), borderWidth=1, borderPadding=6,
                          spaceBefore=4, spaceAfter=6, alignment=TA_CENTER)
story.append(P("<b>纠正报告 —— 本报告与用户初始意图相反，以数据为准。</b><br/>"
    "以下判定完全由数据（OLS F 检验 + 95% 置信区间 + LassoCV）决定；"
    "未对显著性、回归系数或置信区间做任何迎合性调整。", corr_lbl))
story.append(Paragraph(
    "The user expected <b>KRAS</b> to be TP53&rsquo;s strongest <b>positive</b> predictor (coefficient &gt; 0.5). "
    "The multiple linear regression TP53 ~ KRAS + EGFR + Age + Sex returns a KRAS coefficient of <b>%+.3f</b> "
    "(95%% CI [%+.3f, %+.3f], p &lt; 0.001) &mdash; the entire interval lies below zero. The strongest <b>positive</b> "
    "predictor is EGFR (%+.3f); the standardized betas rank EGFR first (0.552) and KRAS second but with the opposite "
    "sign (-0.446). Age and Sex carry no signal (p = 0.27 and 0.07).<br/><br/>"
    "虽然用户预期 KRAS 为正向预测因子，但数据表明其实际效应为<b>负</b>且显著"
    "(系数 = %+.3f, 95%% CI [%+.3f, %+.3f], p &lt; 0.001)。本结论基于整体 F 检验 (F = %.1f, p &asymp; 2.1e-221) 与置信区间："
    "CI 上界 %+.3f 仍远低于 0，KRAS 对 TP53 的正向驱动假设在抽样误差范围内即可被排除。Lasso 交叉验证独立复核得到同一结论："
    "KRAS 在整条正则化路径上恒为负号，CV 最优模型保留 KRAS(-) 与 EGFR(+)，仅把空协变量 Age/Sex 压缩为 0。"
    "模型自动选定的正向驱动基因为 EGFR。也就是说，用户把效应的<b>符号</b>与<b>归属对象</b>同时搞反了。" %
    (kras_coef, kras_ci[0], kras_ci[1], egfr_coef, kras_coef, kras_ci[0], kras_ci[1], ols.fvalue, kras_ci[1]), vb))
story.append(P("Honesty notes: no p-value, regression coefficient, or confidence interval in this report was adjusted to "
    "match the user&rsquo;s expectation; every statistic is reported as estimated. The automated figure review endpoint "
    "(figure_review) returned an RPC error in this session and was replaced by a manual five-point figure checklist "
    "(continuous diverging color scale, labelled axes + colorbar, no excluded rows, heatmap is the correct chart type for "
    "a correlation matrix, file rendered &amp; pixel-verified non-blank).", st_body))

story.append(Spacer(1, 8))
story.append(P("5&nbsp;&nbsp;Data-analysis memo (indication-dossier style)", st_h))
memo_txt = ("""<b>MEMORANDUM &mdash; TP53 driver interrogation (expression screen)</b><br/>
<b>Indication context:</b> identification of transcriptional predictors of TP53 co-expression (diagnostic companion).<br/>
<b>Question:</b> is KRAS the dominant positive driver of TP53?<br/>
<b>Analysis object:</b> 5-variable expression matrix (TP53, KRAS, EGFR, Age, Sex), n = 500.<br/>
<b>Data source:</b> simulated pseudo-true raw expression matrix; 数据来源：模拟真实表达矩阵，版本 v1.0.<br/>
<b>Analytical route:</b> descriptive + Pearson correlation &rarr; OLS (TP53 ~ KRAS+EGFR+Age+Sex) with VIF &rarr; LassoCV (5-fold) path.<br/>
<b>Key result:</b> KRAS &beta; = %+.3f (negative, p&lt;0.001); EGFR &beta; = %+.3f (positive, p&lt;0.001); Age/Sex null; VIF &le; 2.3.<br/>
<b>Interpretation:</b> user hypothesis rejected; KRAS is anti-correlated with TP53 in this simulated ground truth, EGFR is the positive driver.<br/>
<b>Action required:</b> do not advance a KRAS-positive driver narrative; revisit upstream hypothesis; rerun on real data before external release.<br/>
<b>Reproducibility:</b> seed 202409; code in expression_analysis.py; executed notebook final_analysis.ipynb.""" %
            (kras_coef, egfr_coef))
story.append(Paragraph(memo_txt, st_memo))

doc.build(story, onFirstPage=page_deco, onLaterPages=page_deco)
print("PDF built ->", pdf_path, "exists:", os.path.exists(pdf_path), "size:", os.path.getsize(pdf_path))
print("\nDONE. artifacts in", PROJ)
