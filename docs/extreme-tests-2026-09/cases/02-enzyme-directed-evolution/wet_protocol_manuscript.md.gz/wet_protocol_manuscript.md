> **此协议基于干实验计算生成，湿实验员需在实施前核对引物Tm。**

# 操作手稿：GFP S65T / S65A 点突变构建 + 96孔荧光动力学检测（Dry→Wet 闭环 v1）

**干-湿闭环标识**：`parent = mGFP_parent`（虚构 GFP 突变体亲本，240 aa，Python 固定种子 42 生成），本手稿给出从**干实验产物**（引物/板布局）到**湿实验操作**的完整衔接。

## 1. 目的与设计概要
- 亲本：240 aa 虚构 GFP 突变体 `mGFP_parent`，第 65 位为 **Ser（S）**。
- 目标突变：**S65T**（`TCT→ACT`，单碱基）、**S65A**（`TCT→GCT`，单碱基），编码序列由干实验确定性反译（720 nt 合成 CDS，无终止密码子）。
- 湿实验设计：96 孔 **stopped 时间序列板**（0/10/30/60 min），每 (突变体 × 时间点) 8 个重复孔 → 3×4×8=96 孔。
- 输出读数：荧光强度 RFU（Ex 485 / Em 510），记入 `wet_data_raw.csv`。

## 2. 干实验输入参数

| 参数 | 值 |
|---|---|
| 亲本蛋白长度 | 240 aa |
| 亲本蛋白序列 | `EAKIIFEVDWQCADHITYAVHVQIRWKAGQMKFHMEDPENNYKCRVEPDVLYNWHDCILDIEPKSNGNNHKDYGVIGRPKVIMCICMPKDHWMHSPRFKFIVVKWQWPNIFTSDCEFGQYDPPYRTKVAEVKMELQGRAKTGTELTYHFNGVTAYMSAENLICIWDDSDVFFSVGKTYQHVHLPNRTREIIDMAWVIWIADCIDCMDTIKSHVFWWSISQHEEQNQQRCECPMEIHHVRF` |
| 合成 CDS（反译，无终止子，720 nt） | GC 60.0%；位置 192–194 = TCT（编码 S65） |
| 第 65 位密码子 / 氨基酸 | `TCT` / Ser |

> 理论性质（由 Biopython `ProtParam` 计算，供后续定量换算使用）：pI = 5.94；MW ≈ 28618 Da；ε280(reduced, Gill–von Hippel) = 5500·W+1490·Y+125·C = 75285 M⁻¹·cm⁻¹。注：Ser/Thr/Ala 均不带电荷且不影响 W/Y/C 计数，故 S65T/S65A 的 pI 与 ε280 理论上与亲本一致。

## 3. 引物（重叠延伸 PCR / OE）
下表与 `@wet_handoff/primers.csv` 一致；每对内部引物在 5' 端含 **20 bp（18–22 bp 规格）同源臂**（含突变密码子），3' 端为基因锚定尾（18–22 nt）。

| 引物名称 | 序列 (5'→3') | Tm (℃) | GC (%) |
|---|---|---|---|
| S65T_IF | `CGAGCCGAAGACTAACGGGAACAACCACAAGGACTACG` | 67.8 | 55.3 |
| S65T_IR | `TCCCGTTAGTCTTCGGCTCGATGTCCAGGATGCAGTCG` | 69.5 | 57.9 |
| S65A_IF | `CGAGCCGAAGGCTAACGGGAACAACCACAAGGACTACG` | 69.3 | 57.9 |
| S65A_IR | `TCCCGTTAGCCTTCGGCTCGATGTCCAGGATGCAGTCG` | 71.0 | 60.5 |

**OE 装配方案（每个突变体需 2 个内侧引物 + 2 个外侧引物）**：
- 片段 A（亲本基因 5'→突变位点上游）：`OF` + `S65?_IR`；
- 片段 B（突变位点下游→基因 3'）：`S65?_IF` + `OR`；
- 两片段经 20 bp 同源臂退火 → OE 延伸 → 外侧引物再扩增全长。

**外侧扩增引物（OE 配套，辅助；不列入 `primers.csv` 的两个突变引物对）**：

| 引物名称 | 序列 (5'→3') | Tm (℃) | GC (%) |
|---|---|---|---|
| OF (5' 外侧, 正向) | `GAGGCGAAGATCATCTTCGA` | 51.5 | 50.0 |
| OR (3' 外侧, 反向) | `GAACCTCACGTGGTGGATCT` | 53.6 | 55.0 |

## 4. 96 孔板布局
机器可读布局见 `@wet_handoff/96_well_plate_layout.json`（96 个孔均标注 `mutant` 与 `timepoint_min`）。

### 4.1 布板规则
| 列块 | 突变体 | 各列对应时间点 (min) |
|---|---|---|
| 列 1–4 | parent | 0 / 10 / 30 / 60 |
| 列 5–8 | S65T | 0 / 10 / 30 / 60 |
| 列 9–12 | S65A | 0 / 10 / 30 / 60 |

每 (突变体 × 时间点) 的 8 个重复孔分布在行 A–H。

### 4.2 板图（P=parent, T=S65T, A=S65A；数字为停止/读数时间 min）
```
             1      2      3      4      5      6      7      8      9     10     11     12
  A   P-0    P-10   P-30   P-60   T-0    T-10   T-30   T-60   A-0    A-10   A-30   A-60
  B   P-0    P-10   P-30   P-60   T-0    T-10   T-30   T-60   A-0    A-10   A-30   A-60
  C   P-0    P-10   P-30   P-60   T-0    T-10   T-30   T-60   A-0    A-10   A-30   A-60
  D   P-0    P-10   P-30   P-60   T-0    T-10   T-30   T-60   A-0    A-10   A-30   A-60
  E   P-0    P-10   P-30   P-60   T-0    T-10   T-30   T-60   A-0    A-10   A-30   A-60
  F   P-0    P-10   P-30   P-60   T-0    T-10   T-30   T-60   A-0    A-10   A-30   A-60
  G   P-0    P-10   P-30   P-60   T-0    T-10   T-30   T-60   A-0    A-10   A-30   A-60
  H   P-0    P-10   P-30   P-60   T-0    T-10   T-30   T-60   A-0    A-10   A-30   A-60
```

## 5. 湿实验步骤（模拟参数，湿实验员可据实调整）
1. **突变体构建**：以亲本 CDS 为模板，按第 3 节 OE 方案引入 S65T / S65A；Sanger 测序验证。
2. **表达与铺板**：3 个构建体分别转化表达宿主，诱导表达；按 OD600 归一化菌液。
3. **96 孔动力学（stopped assay）**：每孔 100 µL 培养体系（每列块一个突变体，行 A–H 为 8 重复）；37 °C 振荡孵育。
4. **终止/读数**：到 0/10/30/60 min 时，对应列孔加入 50 µL 终止缓冲液；全部终止后统一酶标仪读数 **Ex 485 / Em 510（RFU）**。
5. **数据记录**：逐孔记录 `well_id, mutant, timepoint_min, replicate, RFU` → `wet_data_raw.csv`。

## 6. 质控与移交
- 引物 Tm 为最近邻法（Biopython `MeltingTemp.Tm_NN`）估计值，**实施前需湿实验员实测/复核**。
- 96 孔布局须以 `@wet_handoff/96_well_plate_layout.json` 为准逐孔核对后再加样。
- 移交文件：`@wet_handoff/primers.csv`、`@wet_handoff/96_well_plate_layout.json`、`@wet_handoff/pipetting_scheme.md`。

---
## 7. 干-湿闭环反馈区（已回填 v1）

**回填依据**：`@wet_data_raw.csv` 单因素 ANOVA + Tukey HSD（60-min 终点，剔除 2 个 QC 检出的加样异常值孔 C12、H11 后）。

- 60-min 终点均值±SD：S65T 163.2±7.7（字母 a） > parent 123.9±3.8（字母 b） > S65A 63.1±4.2（字母 c）。
- ANOVA F(2,20)=608.7，p<0.001；Tukey 两两显著。斜率活性折算 S65T ≈ +33%、S65A ≈ -52%（相对亲本）。
- **闭环判定**：湿数据**支持**干预测（S65T>亲本>S65A），未出现“否定干预期”情形，故**不改写**本手稿主体；此节作为闭环备注留痕。
- **若未来真实湿数据与干预测相悖**（例如 S65A 表现不差于亲本、或 S65T 不显著优于亲本），须：
  ① 复核 `@wet_handoff/primers.csv` 引物与克隆正确性；② 回到本手稿 §3 检查突变是否引入；
  ③ 在本节下方追加“改写备注”，并用新数据替换 `@wet_data_raw.csv` 后重跑统计（见 `@final_report.md`）。
